package miniproject;

public class Dobby_Start {

	public static void main(String[] args) {
		new Dobby_Consumer_Main();
	}

}
