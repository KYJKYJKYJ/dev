package java0918_class;

	public class Person {
		String name;
		int age;
		char gen;
		
		void eat() { System.out.println("먹는다"); }
		void run() { System.out.println("달린다"); }
		
	}

