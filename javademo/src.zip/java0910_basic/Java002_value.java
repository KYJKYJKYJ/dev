package java0910_basic;

//주석 : comment, 부가적 설명 (한줄 주석)

 
 /*
  다중 주석
  */
 

/**
 * document에 대한 주석 처리
 */

public class Java002_value {
	public static void main(String[] args) {
		
		/*System.out.println(3);
		System.out.println(3);*/
		
		int num = 10;
		
		System.out.println(num);
		System.out.println(num);
	}
}
