package java0910_basic;

public class Java008_operator {

	public static void main(String[] args) {
		int a = 3;
		
		++a;
		System.out.println("a=" + a);
		
		int b = 4;
		
		--b;
		System.out.println("b=" + b);
		
		final int c = 10; // final 키워드는 상수화 키워드. 변수의 값이 변하지 않게됨
		System.out.println("c=" + c);

	}

}
