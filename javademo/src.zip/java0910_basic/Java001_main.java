package java0910_basic;

public class Java001_main {
	public static void main(String[] args) {
		System.out.println("Hello start");
	}
}
