package java0910_basic;

public class Java010_operator {

	public static void main(String[] args) {
		
		int x = 5;
		int y = 3;
		int z = 5;

		System.out.println(x > y);
		
		System.out.println(x < y);

		System.out.println(x >= z);
		
		System.out.println(x <= z);
		
		System.out.println(x == z);
		
		System.out.println(x != z);
		
	}

}
