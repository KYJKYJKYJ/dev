package java0910_basic;

public class Java007_operator {

	public static void main(String[] args) {
		int numa = 3;
		int numb = 4;
		
		System.out.println("3 + 4 = " +/*문자열연결*/ (numa +/*산술연산*/ numb));

	}

}
