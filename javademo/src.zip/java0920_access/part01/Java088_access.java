package java0920_access.part01;

public class Java088_access {

	public static void main(String[] args) {
		Java087_access j87 = new Java087_access();
		//System.out.println(j87.var_private);
		System.out.println(j87.var_protected);
		System.out.println(j87.var_default);
		System.out.println(j87.var_public);

	}

}
