package java0912_statement;

public class Java032_for {

	public static void main(String[] args) {
		int sum = 0;
		int i = 1;
		
		for(i = 1; i <= 10; i++) {
			sum += i;
			System.out.println(sum);
		}
	}
}
