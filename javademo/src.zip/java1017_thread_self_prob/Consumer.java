package java1017_thread_self_prob;

public class Consumer extends Thread {
	
}
