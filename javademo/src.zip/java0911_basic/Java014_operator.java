package java0911_basic;

public class Java014_operator {

	public static void main(String[] args) {
		int a = 3;
		int b = 4;
		int res = 0;
		
//		res = a + b;
//		System.out.println(res);
		
//		res = res + a;
		res += a;
		System.out.println(res);

	}

}
