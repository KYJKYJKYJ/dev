package java0928_binding;

public class SamsungTv2 extends HomeTv{
	public SamsungTv2() {
		
	}
	
	public SamsungTv2(String maker) {
		super(maker);
	}
	
	public void loc() {
		System.out.println("samsung loc");
	}

}
