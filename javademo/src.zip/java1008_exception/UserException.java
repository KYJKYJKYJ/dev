package java1008_exception;

//사용자 정의 예외 클래스
public class UserException extends Exception{
	public UserException(String message) {
		super(message);
	}
} //end class
